struct biglietto{
    char nomeUtente[30];
    int mezzoDiTrasporto;
    int tipoViaggio;
    int dettaglio;
    int partenza;
    int destinazione;
    int albergo;
    struct biglietto *next;
};


void gestisci_errore(int x);
struct biglietto *creaNodo(char *nome, int mezzo, int tipo, int dettaglio, int part, int dest, int alb);
struct biglietto *inserimentoBiglietto(struct biglietto *head, char *nome, int mezzo, int tipo, int dettaglio, int part, int dest, int alb);
void stampa_lista(struct biglietto *head);
void dealloca_lista(struct biglietto *head);
void trovaBiglietto(struct biglietto *lista, char *nomeUtente);

