#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <curses.h>
#include "StrutturaViaggio.h"
#include "StruttureUtente.h"
#include "StrutturaCitta.h"
#include "FunzioniRichieste.h"
#include "FunzioniBiglietto.h"


int main()
{
    int sceltaAccesso;
    int verificaAccesso=0;
    int verificaUnicitàNomeUtente;
    int sceltaOpClient;
    int sceltaOpAdmin;
    int ripetizioneInterfacciaClient=0;
    int ripetizioneInterfacciaAdmin=0;
    
    int sceltaMezzoDiTrasporto=0;
    int sceltaTipologiaViaggio=0;
    int cittaPartenza;
    int cittaArrivo;
    int hotelRaggiungere;
    
    char **vettoreCitta=NULL;
    char **vettoreHotel;
    
    int minV=INT_MAX;
    int minE=INT_MAX;
    int minC=INT_MAX;
    int minTmp=INT_MAX;
    
    char ctTemp[15];
    char cittaSceltaDestinazione[15];
    int tmpviaggio;
    int tmpcitta;
    
    int sceltaRichiesta=0;
    int sceltaConferma=0;
    int contaRichieste;
    int prezzoScelto;
    int distanzaScelta;
    int numnodi;
    int m;
    
    char nom[30];
    int mez;
    int tipv;
    int dett;
    int part;
    int dest;
    int alb;
    int contatoreBiglietti=0;
    
    FILE *fp=NULL;
    
    char nomeUtenteLive[LENGTH_NOME_UTENTE];
    char passwordLive[LENGTH_PASSWORD];
    
    struct utente *treeAdmin=NULL;
    struct utente *treeClient=NULL;
    
    struct viaggio *grafoViaggio=NULL;
    struct viaggio *grafoAlternativo=NULL;
    struct citta *grafoCitta=NULL;
    
    struct nodoViaggio *listaVeloce;
    struct nodoViaggio *listaEconomica;
    struct nodo *listaVeloceCitta;
    struct nodoViaggio *listaTmp;
    
    struct richiesta *tmpRichiesta=NULL;
    struct richiesta *listaRichieste=NULL;
    
    struct biglietto *listaBiglietti=NULL;
    struct biglietto *tmpBiglietti=NULL;
    
    //Carichiamo nel programma le informazioni necessarie per il login.

    fp=fopen("AdminLog.txt","r");
    treeAdmin=leggiFileLog(treeAdmin, fp);
    fclose(fp);
    
    fp=fopen("ClientLog.txt","r");
    treeClient=leggiFileLog(treeClient, fp);
    fclose(fp);
    
    //Scegliamo in che modo Accedere.
    sceltaAccesso=sceltaLogin();
    printf("\n");
    
    listaRichieste=leggiFileRichieste(listaRichieste);
    
    //Entro in questo if se ho scelto di registrarmi.
    if(sceltaAccesso==3)
    {
        do{
            printf("Benvenuto/a, Inserisci un nome utente e una password.\n");
            printf("Nome utente: ");
            scanf("%s",nomeUtenteLive);
            printf("Password: ");
            scanf("%s",passwordLive);
            
            //Verifichiamo se il nome utente inserito non sia stato già preso da un altro cliente.
            verificaUnicitàNomeUtente=unicitàNomeUtente(treeClient, nomeUtenteLive);
            
            if(verificaUnicitàNomeUtente==1)
                printf("Mi dispiace, nome utente già utilizzato...Riprova.\n\n");
            else
            {
                //Inseriamo in treeClient il nuovo utente.
                treeClient=inserimentoUtente(treeClient, nomeUtenteLive, passwordLive);
                
                //Aggiorniamo il file ClientLog con le credenziali del nuovo cliente.
                fp=fopen("ClientLog.txt","a");
                updateFileLogClient(fp,nomeUtenteLive,passwordLive);
                fclose(fp);
            }
        }while(verificaUnicitàNomeUtente==1);   //Usciremo da questo While quando inseriremo un nome utente univoco.
    
        //Entriamo in questo else se ho scelto di accedere come Admin o come Client.
    }
    else
    {
        do{
            printf("Inserire Nome Utente e Password per effettuare il login:\n");
            printf("Nome Utente: ");
            scanf("%s",nomeUtenteLive);
            printf("Password: ");
            scanf("%s",passwordLive);
            
            //Verifichiamo se l'accesso è stato richiesto da un Admin o da un Client.
            //Questa informazione sarà utile per capire se effettuare la ricerca delle credenziali in treeClient o treeAdmin.
            if(sceltaAccesso==1)
                verificaAccesso=ricercaTreeUtente(treeAdmin, nomeUtenteLive, passwordLive);
            else
                verificaAccesso=ricercaTreeUtente(treeClient, nomeUtenteLive, passwordLive);
            
            //Se entriamo in questi due casi vuol dire che nome utente o password sono errati.
            if(verificaAccesso==0)
                printf("Nome Utente e Password Errati.\n\n");
            else if(verificaAccesso==3)
                printf("Password Errata.\n\n");
            
        }while(verificaAccesso==0 || verificaAccesso==3);
    }
    
    //Se entriamo in questo if vuol dire che siamo dei clienti, e possiamo effettuare solo determinate operazioni.
    if(sceltaAccesso==2 || sceltaAccesso==3)
    {
        do{
            ripetizioneInterfacciaClient=0;             //Variabile di controllo per gestire il menù.
            sceltaOpClient=sceltaOperazioneClient();    //Scegliamo che operazione effettuare.
            printf("\n");
            if(sceltaOpClient==1) //Per effettuare una prenotazione
            {
                do{
                    //Scegliamo quale mappa aprire in base al mezzo di trasporto.
                    printf("Scegli quale mezzo di trasporto utilizzare:\n1-Aereo\n2-Treno\n");
                    scanf("%d",&sceltaMezzoDiTrasporto);
                    if (sceltaMezzoDiTrasporto==1)
                    {
                        fp=fopen("ViaggioAereo.txt","r");
                        grafoViaggio=implementaGrafoViaggio(grafoViaggio,fp);
                        fclose(fp);
                        
                        fp=fopen("ViaggioAereo.txt","r");
                        vettoreCitta=leggiFileViaggioCitta(fp,grafoViaggio->numCitta);
                        fclose(fp);
                    }
                    else if(sceltaMezzoDiTrasporto==2)
                    {
                        fp=fopen("ViaggioTreno.txt","r");
                        grafoViaggio=implementaGrafoViaggio(grafoViaggio,fp);
                        fclose(fp);
                        
                        fp=fopen("ViaggioTreno.txt","r");
                        vettoreCitta=leggiFileViaggioCitta(fp,grafoViaggio->numCitta);
                        fclose(fp);
                    }
                    else if (sceltaMezzoDiTrasporto!=1 && sceltaMezzoDiTrasporto!=2)
                    {
                        printf("\nErrore, riprova.\n\n");
                    }
                }while(sceltaMezzoDiTrasporto!=1 && sceltaMezzoDiTrasporto!=2);
            
                //Scegliamo dove la città di partenza e di destinazione.
                tmpviaggio=0;
                do{
                    printf("\n");
                    sceltaPartenzaeDestinazione(vettoreCitta,grafoViaggio->numCitta);
                    printf("\n");
                    printf("Scegli la città di partenza: ");
                    scanf("%d",&cittaPartenza);
                    printf("Scegli la città di destinazione: ");
                    scanf("%d",&cittaArrivo);
            
                    if ((cittaPartenza>=grafoViaggio->numCitta||cittaArrivo>=grafoViaggio->numCitta) || (cittaPartenza<0 || cittaArrivo<0))
                    {
                        sceltaOpClient=1;
                        printf("\nErrore riprova.\n");
                    }
                    else if(cittaArrivo==cittaPartenza)
                    {
                        sceltaOpClient=1;
                        printf("\nErrore riprova.\n");
                    }
                    else
                    {
                        sceltaOpClient=0;
                    }
                }while(sceltaOpClient==1);
              
                //Carichiamo le due liste, una contenente il percorso più breve e una per il percorso più economico.
                listaVeloce=TrovaPercorsoMinimoV(grafoViaggio, cittaPartenza, cittaArrivo, &minV);
                listaEconomica=TrovaPercorsoEconomicoV(grafoViaggio, cittaPartenza, cittaArrivo, &minE);
                
                if (listaVeloce!=NULL && listaEconomica!=NULL)
                {
                    printf("\nPercorso più veloce:\n");
                    StampaPercorsoNominatoV(listaVeloce,vettoreCitta);
                    printf("\n");
                    printf("Kilometri totali: %d.\n",minV);
                    printf("\n");
                    printf("Percorso più economico:\n");
                    StampaPercorsoNominatoV(listaEconomica, vettoreCitta);
                    printf("\n");
                    printf("Prezzo totale: %d.\n",minE);
                
                    do{
                        sceltaOpClient=0;   //Scegliamo un solo percorso.
                        printf("\nScegliere quale dei due percorsi utilizzare:\n1-Tragitto più veloce.\n2-Tragitto più economico.\n");
                        scanf("%d",&sceltaTipologiaViaggio);
               
                        if (sceltaTipologiaViaggio!=1 && sceltaTipologiaViaggio!=2)
                        {
                            printf("\nErrore, riprova.\n");
                            sceltaOpClient=1;
                        }
                    }while(sceltaOpClient==1);
                }
                else
                {
                    //Nel caso in cui una meta non è raggiungibile, controlliamo se con un altro mezzo è possibile raggiungerla.
                    printf("\nNessun percorso disponibile.\n");
                    if(sceltaMezzoDiTrasporto==1)
                    {
                        fp=fopen("ViaggioTreno.txt","r");
                        grafoAlternativo=implementaGrafoViaggio(grafoAlternativo,fp);
                        fclose(fp);
                        listaTmp=TrovaPercorsoMinimoV(grafoAlternativo, cittaPartenza, cittaArrivo, &minTmp);
                    }
                    else
                    {
                        fp=fopen("ViaggioAereo.txt","r");
                        grafoAlternativo=implementaGrafoViaggio(grafoAlternativo,fp);
                        fclose(fp);
                        listaTmp=TrovaPercorsoMinimoV(grafoAlternativo, cittaPartenza, cittaArrivo, &minTmp);
                    }
                    
                    //Entriamo in questo if nel caso in cui esiste un percorso utilizzando un altro mezzo.
                    if(listaTmp!=NULL)
                    {
                        printf("Puoi raggiungere questa meta in ");
                        if (sceltaMezzoDiTrasporto==1)
                        {
                            printf("Treno.\n");
                            deallocaListaViaggio(listaTmp);
                        }
                        else
                        {
                            printf("Aereo.\n");
                            deallocaListaViaggio(listaTmp);
                        }
                    }
                    //Entriamo in questo if nel caso in cui non sia possibile raggiungere in alcun modo quella meta, e viene inviata automaticamente una richiesta all'admin.
                    else
                    {
                        printf("Grazie per la segnalazione, la richiesta verrà inoltrata ad un Admin.\n");
                        if (ricerca(listaRichieste, cittaPartenza, cittaArrivo)!=1)
                        {
                            listaRichieste=inserimento(listaRichieste,cittaPartenza,cittaArrivo);
                            scriviFileRichieste(listaRichieste);
                        }
                    }
                    //Deallochiamo le varie strutture utilizzate e inizializziamo alcune variabili.
                    deallocaVettoreCitta(vettoreCitta, grafoViaggio->numCitta);
                    vettoreCitta=NULL;
                    EliminaGrafo(grafoViaggio);
                    grafoViaggio=NULL;
                    EliminaGrafo(grafoAlternativo);
                    grafoAlternativo=NULL;
                    deallocaListaViaggio(listaVeloce);
                    listaVeloce=NULL;
                    deallocaListaViaggio(listaEconomica);
                    listaEconomica=NULL;
                    minV=INT_MAX;
                    minE=INT_MAX;
                    minC=INT_MAX;
                    tmpviaggio=1;
                }
            
                if(tmpviaggio!=1)
                {
                    //Carichiamo il grafo della città di destinazione.
                    strcpy(ctTemp, vettoreCitta[cittaArrivo]);
                    strcpy(cittaSceltaDestinazione, strcat(ctTemp, ".txt"));
                
                    grafoCitta=CreaGrafoCitta(cittaSceltaDestinazione);
                
                    fp=fopen(cittaSceltaDestinazione,"r");
                    vettoreHotel=leggiFileCitta(fp,grafoCitta->nL);
                    fclose(fp);
                
                    printf("\n");
                    sceltaHotel(vettoreHotel,grafoCitta->nL);   //Viene scelto l'hotel che si vuole raggiungere.
                    do{
                        tmpcitta=0;
                        do{
                            printf("\nScegliere l'Hotel: ");
                            scanf("%d",&hotelRaggiungere);
                            hotelRaggiungere=hotelRaggiungere+2;
                            if((hotelRaggiungere>=grafoCitta->nL)||(hotelRaggiungere<0))
                            {
                                sceltaOpClient=1;
                                printf("\nErrore, riprova.\n");
                            }
                            else
                            {
                                sceltaOpClient=0;
                            }
                        }while(sceltaOpClient==1);

                        //Troviamo il percorso più veloce dalla stazione o aereoporto all'albergo scelto.
                        listaVeloceCitta=TrovaPercorso(grafoCitta, sceltaMezzoDiTrasporto-1, hotelRaggiungere,&minC);
                        if (listaVeloceCitta!=NULL)
                        {
                            printf("\nPercorso più veloce:\n");
                            StampaPercorsoNominato(listaVeloceCitta,vettoreHotel);
                            printf("\n");
                            printf("Kilometri totali: %d.\n",minC);
                            printf("\n");
                        }
                        else
                        {
                            printf("\nNessun percorso disponibile.\nScegliere un'altro Hotel.\n\n");
                            tmpcitta=1;
                        }
                    }while (tmpcitta==1);
                
                    
                    //Stampiamo un resoconto della prenotazione effettuata.
                    printf("Dettagli prenotazione:\n");
                    if (sceltaMezzoDiTrasporto==1)
                        printf("Mezzo di trasporto: Aereo.\n");
                    else
                        printf("Mezzo di trasporto: Treno.\n");
                
                    printf("Tipologia viaggio: ");
                    if (sceltaTipologiaViaggio==1)
                        printf("Veloce.\n");
                    else
                        printf("Economico.\n");
                    printf("Tratta Viaggio: ");
                    if(sceltaTipologiaViaggio==1)
                    {
                        StampaPercorsoNominatoV(listaVeloce, vettoreCitta);
                        printf("\nKilometri: %d",minV);
                        m=minV;
                    }
                    else
                    {
                        StampaPercorsoNominatoV(listaEconomica, vettoreCitta);
                        printf("\nPrezzo: %d",minE);
                        m=minE;
                    }
                    printf(".\n");
                    printf("Albergo Prenotato: %s.\n",vettoreHotel[hotelRaggiungere]);
                    printf("Percorso per raggiungere l'Albergo: ");
                    StampaPercorsoNominato(listaVeloceCitta, vettoreHotel);
                    printf("\n");
                    do{
                        printf("\nConfermare la prenotazione?\n");
                        printf("1 -SI\n2 -NO\n");
                        scanf("%d",&sceltaConferma);
                        //Se accettiamo la prenotazione, le varie informazioni saranno salvate in un file.
                        if(sceltaConferma==1)
                        {
                            fp=fopen("Biglietti.txt", "a");
                            fprintf(fp, "%s %d %d %d %d %d %d\n ",nomeUtenteLive,sceltaMezzoDiTrasporto,sceltaTipologiaViaggio,m,cittaPartenza,cittaArrivo,hotelRaggiungere);
                            fclose(fp);
                            printf("\nPrenotazione effettuata con successo.\n");
                        }
                        else if(sceltaConferma==2)
                        {
                            printf("\nPrenotazione non effettuata.\n");
                        }
                        else
                        {
                            printf("\nErrore, riprova.\n");
                        }
                    }while(sceltaConferma!=1 && sceltaConferma!=2); //chiude le scelte delle prenotazioni
                    
                    //Deallochiamo le varie strutture utilizzare e inizializziamo alcune variabili.
                    deallocaVettoreCitta(vettoreCitta, grafoViaggio->numCitta);
                    vettoreCitta=NULL;
                    deallocaVettoreCitta(vettoreHotel, grafoCitta->nL);
                    vettoreHotel=NULL;
                    EliminaGrafo(grafoViaggio);
                    grafoViaggio=NULL;
                    EliminaGrafoCitta(grafoCitta);
                    grafoCitta=NULL;
                    deallocaListaViaggio(listaVeloce);
                    listaVeloce=NULL;
                    deallocaListaViaggio(listaEconomica);
                    listaEconomica=NULL;
                    deallocaListaCitta(listaVeloceCitta);
                    listaVeloceCitta=NULL;
                    minV=INT_MAX;
                    minE=INT_MAX;
                    minC=INT_MAX;
                }
               
                ripetizioneInterfacciaClient=1; //Torniamo alla Home.
            }
            //Entriamo in questo if se abbiamo scelto di visualizzare le prenotazioni effettuate.
            else if(sceltaOpClient==2)
            {
                contatoreBiglietti=0;
                fp=fopen("Biglietti.txt", "r");
                while (fscanf(fp, "%s %d %d %d %d %d %d",nom, &mez, &tipv, &dett, &part, &dest, &alb)==7)
                {
                    listaBiglietti=inserimentoBiglietto(listaBiglietti, nom, mez, tipv, dett, part, dest, alb); //Carichiamo una lista con le prenotazioni.
                }
                fclose(fp);
               
                if (listaBiglietti!=NULL)
                {
                    tmpBiglietti=listaBiglietti;
                    while (tmpBiglietti!=NULL)
                    {
                        //Scegliamo solo le prenotazioni del client che ha effettuato l'accesso.
                        if(strcmp(tmpBiglietti->nomeUtente, nomeUtenteLive)==0)
                        {
                            trovaBiglietto(tmpBiglietti,nomeUtenteLive);
                            contatoreBiglietti++;
                            printf("\n\n");
                        }
                        tmpBiglietti=tmpBiglietti->next;
                    }
                    if (contatoreBiglietti==0)
                    {
                        printf("Non ci sono Prenotazioni.\n\n");
                    }
                    tmpBiglietti=listaBiglietti;
                    dealloca_lista(listaBiglietti);
                    listaBiglietti=NULL;
                }
                else
                {
                    printf("Non ci sono Prenotazioni.\n");
                }
                ripetizioneInterfacciaClient=1;
            }
            //Entriamo in questo if se abbiamo scelto di effettuare il logout.
            else if(sceltaOpClient==3)
            {
                printf("Arrivederci...\n\n");
                ripetizioneInterfacciaClient=0;
            }
            else //Inserimento non valido, per una scelta dalla Home Client.
            {
                printf("Errore, riprova.");
                ripetizioneInterfacciaClient=1;
            }
        }while(ripetizioneInterfacciaClient!=0);
    }
    
    //Se entriamo in questo else vuol dire che siamo degli Admin, e possiamo effettuare solo determinate operazioni.
    else
    {
        do{
            ripetizioneInterfacciaAdmin=0;              //Variabile di controllo per gestire il menù.
            printf("\n");
            sceltaOpAdmin=sceltaOperazioneAdmin();      //Scegliamo che operazione effettuare.
            printf("\n");
            //Se entriamo in questo if vuol dire che vogliamo gestire le richieste arrivate.
            if (sceltaOpAdmin==1)
            {
                fp=fopen("ViaggioAereo.txt","r");
                numnodi=contaNodi(fp);
                fclose(fp);
                
                fp=fopen("ViaggioAereo.txt","r");
                vettoreCitta=leggiFileViaggioCitta(fp,numnodi);
                fclose(fp);
                
                contaRichieste=counter(listaRichieste);
                stampaRichieste(listaRichieste,vettoreCitta);   //Vengono stampate a schermo le varie richieste disponibili.
                printf("\n");
                deallocaVettoreCitta(vettoreCitta,numnodi);
                vettoreCitta=NULL;
                if(listaRichieste!=NULL)
                {
                    do{
                        printf("Inserire la richiesta da gestire: ");   //Scegliamo quale richiesta gestire.
                        scanf("%d",&sceltaRichiesta);
                        if ((sceltaRichiesta>contaRichieste)||(sceltaRichiesta<=0))
                            printf("\nErrore, riprova.\n\n");
                    }while ((sceltaRichiesta>contaRichieste)||(sceltaRichiesta<=0));
                    tmpRichiesta=recuperaNodo(listaRichieste, sceltaRichiesta);
                    printf("\n");
                    //Possiamo scegliere tra queste due possibilità.
                    do{
                        printf("1 -Aggiungi collegamento.\n2 -Elimina meta.\n3 -Ritorna alla Home.\n");
                        scanf("%d",&sceltaRichiesta);
                        if(sceltaRichiesta<0||sceltaRichiesta>3)
                            printf("\nErrore, riprova.\n\n");
                    }while(sceltaRichiesta<0||sceltaRichiesta>3);
                    //Se entriamo in questo if vogliamo aggiungere un collegamento tra due mete.
                    if(sceltaRichiesta==1)
                    {
                        printf("\n");
                        do{
                            printf("Selezionare il mezzo di trasporto:\n");     //Scegliamo con quale mezzo creare il collegamento.
                            printf("1 -Aereo.\n2 -Treno.\n");
                            scanf("%d",&sceltaMezzoDiTrasporto);
                            if(sceltaMezzoDiTrasporto<0 || sceltaMezzoDiTrasporto>2)
                                printf("\nErrore, riprova.\n\n");
                        }while(sceltaMezzoDiTrasporto<0 || sceltaMezzoDiTrasporto>2);
                        //Carichiamo i grafi in base alla scelta effettuata.
                        if(sceltaMezzoDiTrasporto==1)
                        {
                            fp=fopen("ViaggioAereo.txt","r");
                            grafoViaggio=implementaGrafoViaggio(grafoViaggio,fp);
                            fclose(fp);
                                
                            fp=fopen("ViaggioAereo.txt","r");
                            vettoreCitta=leggiFileViaggioCitta(fp,grafoViaggio->numCitta);
                            fclose(fp);
                        }
                        else
                        {
                            fp=fopen("ViaggioTreno.txt","r");
                            grafoViaggio=implementaGrafoViaggio(grafoViaggio,fp);
                            fclose(fp);
                                
                            fp=fopen("ViaggioTreno.txt","r");
                            vettoreCitta=leggiFileViaggioCitta(fp,grafoViaggio->numCitta);
                            fclose(fp);
                        }
                        
                        printf("\n");
                        printf("Aggiungere prezzo: ");  //Aggiungiamo il prezzo per la tratta.
                        do{
                            scanf("%d",&prezzoScelto);
                            if(prezzoScelto<0)
                                puts("Errore: prezzo inserito non valido.\n");
                        }while(prezzoScelto<0);
                            
                        printf("\nAggiungere distanza: ");  //Aggiungiamo la distanza per la tratta.
                        do{
                            scanf("%d",&distanzaScelta);
                            if(distanzaScelta<0)
                                printf("Errore: distanza inserita non valida.\n");
                        }while(distanzaScelta<0);
                        
                        //Richiamiamo la funzione che ci collega le due mete in questione.
                        aggiungiTrattaViaggio(grafoViaggio,tmpRichiesta->src, tmpRichiesta->dest, prezzoScelto, distanzaScelta);
                            
                        //Aggiorniamo i file.
                        if(sceltaMezzoDiTrasporto==1)
                        {
                            ScriviFileViaggio("ViaggioAereo.txt",grafoViaggio, vettoreCitta);
                        }
                        else
                        {
                            ScriviFileViaggio("ViaggioTreno.txt", grafoViaggio, vettoreCitta);
                        }
                        
                        printf("\nCollegamento aggiunto con successo.\n");
                        listaRichieste=rimuoviRichiesta(listaRichieste,tmpRichiesta->src,tmpRichiesta->dest);   //Rimuoviamo la richiesta appena risolta.
                        scriviFileRichieste(listaRichieste);    //Aggiorniamo il file richieste.
                        deallocaVettoreCitta(vettoreCitta, grafoViaggio->numCitta);
                        vettoreCitta=NULL;
                        EliminaGrafo(grafoViaggio);
                        grafoViaggio=NULL;
                        tmpRichiesta=NULL;
                        ripetizioneInterfacciaAdmin=1;
                    }
                    //Se entriamo in questo if abbiamo scelto di eliminare la meta non raggiungibile.
                    else if(sceltaRichiesta==2)
                    {
                        fp=fopen("ViaggioAereo.txt","r");
                        grafoViaggio=implementaGrafoViaggio(grafoViaggio,fp);
                        fclose(fp);
                            
                        fp=fopen("ViaggioAereo.txt","r");
                        vettoreCitta=leggiFileViaggioCitta(fp,grafoViaggio->numCitta);
                        fclose(fp);
                            
                        fp=fopen("ViaggioTreno.txt","r");
                        grafoAlternativo=implementaGrafoViaggio(grafoAlternativo,fp);
                        fclose(fp);
                            
                        //Se entriamo in questo if vuol dire che la destinazione è collegata eventualmente ad altre mete.
                        if((collegamentoNodo(grafoViaggio, tmpRichiesta->dest)==1)||(collegamentoNodo(grafoAlternativo, tmpRichiesta->dest))==1)
                        {
                            printf("\nSono presenti dei collegamenti entranti o uscenti dalla città.\n");
                            printf("Impossibile eliminare la destinazione.\n");
                        }
                        //Se entriamo in questo if vuol dire che la destinazione non è collegata a nessun'altra meta e quindi l'eliminazione avviene in modo automatico.
                        else
                        {
                            vettoreCitta=UpdateVetLuoghi(vettoreCitta,tmpRichiesta->dest,grafoViaggio->numCitta);
                            grafoViaggio=RimuoviNodo(grafoViaggio,tmpRichiesta->dest);
                            ScriviFileViaggio("ViaggioAereo.txt",grafoViaggio,vettoreCitta);
                            grafoAlternativo=RimuoviNodo(grafoAlternativo, tmpRichiesta->dest);
                            ScriviFileViaggio("ViaggioTreno.txt",grafoAlternativo,vettoreCitta);
                            printf("\nLa meta è stata eliminata con successo.\n");
                            listaRichieste=rimuoviCitta(listaRichieste,tmpRichiesta->dest);
                            listaRichieste=aggiornaRichieste(listaRichieste,tmpRichiesta->dest);
                            scriviFileRichieste(listaRichieste);
                        }
                        
                        //Deallochiamo le strutture utilizzare e inizializziamo alcune variabili.
                        deallocaVettoreCitta(vettoreCitta,grafoViaggio->numCitta);
                        vettoreCitta=NULL;
                        EliminaGrafo(grafoViaggio);
                        grafoViaggio=NULL;
                        EliminaGrafo(grafoAlternativo);
                        grafoAlternativo=NULL;
                        tmpRichiesta=NULL;
                        ripetizioneInterfacciaAdmin=1;
                    }
                    //Entriamo in questo if se non vogliamo gestire nessuna richiestra tra quelle elencate.
                    else if(sceltaRichiesta==3)
                    {
                        ripetizioneInterfacciaAdmin=1;
                    }
                }
                //Entriamo in questo if se non ci sono richieste disponibili.
                else
                {
                    ripetizioneInterfacciaAdmin=1;
                }
            }
            //Entriamo in questo if se abbiamo deciso di effettuare il logout.
            else if(sceltaOpAdmin==2)
            {
                printf("Arrivederci...\n\n");
                ripetizioneInterfacciaAdmin=0;
            }
            else
            {
                ripetizioneInterfacciaAdmin=1;
            }
        }while(ripetizioneInterfacciaAdmin!=0);
    }
    
    //Deallochiamo le varie strutture ancora allocata nel programma.
  
    svuotaListaRichieste(listaRichieste);
    listaRichieste=NULL;
    
    deallocazioneUtente(treeClient);
    treeClient=NULL;
    
    deallocazioneUtente(treeAdmin);
    treeAdmin=NULL;

    return 0;
}

