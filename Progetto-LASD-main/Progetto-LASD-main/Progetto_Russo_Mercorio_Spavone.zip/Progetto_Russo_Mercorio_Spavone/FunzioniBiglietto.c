#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "FunzioniBiglietto.h"
#include "StrutturaViaggio.h"
#include "StrutturaCitta.h"


void gestisci_errore(int x)
{
  if(x==1)
  {
    printf("Allocazione non avvenuta.\n");
    exit (-1);
  }
  else if(x==2)
  {
    printf("Apertura file non riuscita.\n");
    exit(-1);
  }
}


struct biglietto *creaNodo(char *nome, int mezzo, int tipo, int dettaglio, int part, int dest, int alb)
{
    struct biglietto *elem;
    elem=(struct biglietto *)malloc(sizeof(struct biglietto));
    if(elem==NULL)
        gestisci_errore(1);
    strcpy(elem->nomeUtente, nome);
    elem->mezzoDiTrasporto=mezzo;
    elem->tipoViaggio=tipo;
    elem->dettaglio=dettaglio;
    elem->partenza=part;
    elem->destinazione=dest;
    elem->albergo=alb;
    elem->next=NULL;
    return elem;
}


struct biglietto *inserimentoBiglietto(struct biglietto *head, char *nome, int mezzo, int tipo, int dettaglio, int part, int dest, int alb)
{
    struct biglietto *elem;
    struct biglietto *tmp;
    elem=creaNodo(nome, mezzo, tipo, dettaglio, part, dest, alb);
    if(head==NULL)
        return elem;
    tmp=head;
    while(tmp->next!=NULL)
    {
        tmp=tmp->next;
    }
    tmp->next=elem;
    return head;
}


void stampa_lista(struct biglietto *head)
{
    while(head!=NULL)
    {
        
        head=head->next;
    }
    printf("NULL\n");
}


void dealloca_lista(struct biglietto *head)
{
    struct biglietto *tmp;
    tmp=head;
    while(head!=NULL)
    {
        head=head->next;
        free(tmp);
        tmp=head;
    }
}

void trovaBiglietto(struct biglietto *lista, char *nomeUtente)
{
    struct viaggio *grafoViaggio=NULL;
    struct citta *grafoCitta=NULL;
    struct nodoViaggio *listaPercorso;
    struct nodo *listaVeloceCitta;
    int min=INT_MAX;
    int min2=INT_MAX;
    char **vettoreCitta=NULL;
    char **vettoreHotel;
    char ctTemp[15];
    char cittaSceltaDestinazione[15];
    char stampa[66];
    int i=0;
    long int lunghezza=0;
    
    FILE *fp;
    
    if (lista->mezzoDiTrasporto==1)
    {
        fp=fopen("ViaggioAereo.txt","r");
        grafoViaggio=implementaGrafoViaggio(grafoViaggio,fp);
        fclose(fp);
        
        fp=fopen("ViaggioAereo.txt","r");
        vettoreCitta=leggiFileViaggioCitta(fp,grafoViaggio->numCitta);
        fclose(fp);
    }
    else if(lista->mezzoDiTrasporto==2)
    {
        fp=fopen("ViaggioTreno.txt","r");
        grafoViaggio=implementaGrafoViaggio(grafoViaggio,fp);
        fclose(fp);
        
        fp=fopen("ViaggioTreno.txt","r");
        vettoreCitta=leggiFileViaggioCitta(fp,grafoViaggio->numCitta);
        fclose(fp);
    }
    if (lista->tipoViaggio==1)
    {
        listaPercorso=TrovaPercorsoMinimoV(grafoViaggio, lista->partenza, lista->destinazione, &min);
    }
    else
    {
        listaPercorso=TrovaPercorsoEconomicoV(grafoViaggio, lista->partenza, lista->destinazione, &min);
    }
   
    strcpy(ctTemp, vettoreCitta[lista->destinazione]);
    strcpy(cittaSceltaDestinazione, strcat(ctTemp, ".txt"));
    grafoCitta=CreaGrafoCitta(cittaSceltaDestinazione);
    fp=fopen(cittaSceltaDestinazione,"r");
    vettoreHotel=leggiFileCitta(fp,grafoCitta->nL);
    fclose(fp);
    listaVeloceCitta=TrovaPercorso(grafoCitta, lista->mezzoDiTrasporto-1, lista->albergo,&min2);
    
    strcpy(stampa, "/////////////////////////////////////////////////////////////////");
    printf("%s\n",stampa);
    strcpy(stampa, "/// NomeUtente: ");
    strcat(stampa, nomeUtente);
    strcat(stampa, " ");
    lunghezza=65-strlen(stampa);
    printf("%s",stampa);
    for (i=0; i<lunghezza-3; i++)
    {
        printf(" ");
    }
    printf("///");
    printf("\n");
    strcpy(stampa, "/////////////////////////////////////////////////////////////////");
    printf("%s\n",stampa);
    if (lista->mezzoDiTrasporto==1)
        strcpy(stampa, "/// Mezzo di trasporto: Aereo. ");
    else
        strcpy(stampa, "/// Mezzo di trasporto: Treno. ");
    printf("%s",stampa);
    lunghezza=65-strlen(stampa);
    for (i=0; i<lunghezza-3; i++)
    {
        printf(" ");
    }
    printf("///");
    printf("\n");
    strcpy(stampa, "/////////////////////////////////////////////////////////////////");
    printf("%s\n",stampa);
    if (lista->tipoViaggio==1)
        strcpy(stampa, "/// Tipologia viaggio: Veloce. ");
    else
        strcpy(stampa, "/// Tipologia viaggio: Economico. ");
    printf("%s",stampa);
    lunghezza=65-strlen(stampa);
    for (i=0; i<lunghezza-3; i++)
    {
        printf(" ");
    }
    printf("///");
    printf("\n");
    strcpy(stampa, "/////////////////////////////////////////////////////////////////");
    printf("%s\n",stampa);
    strcpy(stampa, "/// Partenza: ");
    strcat(stampa, vettoreCitta[lista->partenza]);
    strcat(stampa, " ");
    lunghezza=65-strlen(stampa);
    printf("%s",stampa);
    for (i=0; i<lunghezza-3; i++)
    {
        printf(" ");
    }
    printf("///");
    printf("\n");
    strcpy(stampa, "/////////////////////////////////////////////////////////////////");
    printf("%s\n",stampa);
    strcpy(stampa, "/// Destinazione: ");
    strcat(stampa, vettoreCitta[lista->destinazione]);
    strcat(stampa, " ");
    lunghezza=65-strlen(stampa);
    printf("%s",stampa);
    for (i=0; i<lunghezza-3; i++)
    {
        printf(" ");
    }
    printf("///");
    printf("\n");
    strcpy(stampa, "/////////////////////////////////////////////////////////////////");
    printf("%s\n",stampa);
    if (lista->tipoViaggio==1)
        strcpy(stampa, "/// Kilometri: ");
    else
        strcpy(stampa, "/// Prezzo: ");
    printf("%s",stampa);
    printf("%d",lista->dettaglio);
    lunghezza=65-strlen(stampa);
    if (lista->dettaglio<10)
        lunghezza--;
    else if(lista->dettaglio>9 && lista->dettaglio<100)
        lunghezza=lunghezza-2;
    else if(lista->dettaglio>99 && lista->dettaglio<1000)
        lunghezza=lunghezza-3;
    else if(lista->dettaglio>999 && lista->dettaglio<10000)
        lunghezza=lunghezza-4;
    for (i=0; i<lunghezza-3; i++)
    {
        printf(" ");
    }
    printf("///");
    printf("\n");
    strcpy(stampa, "/////////////////////////////////////////////////////////////////");
    printf("%s\n",stampa);
    strcpy(stampa, "/// Albergo Prenotato: ");
    strcat(stampa, vettoreHotel[lista->albergo]);
    strcat(stampa, " ");
    printf("%s",stampa);
    lunghezza=65-strlen(stampa);
    for (i=0; i<lunghezza-3; i++)
    {
        printf(" ");
    }
    printf("///");
    printf("\n");
    strcpy(stampa, "/////////////////////////////////////////////////////////////////");
    printf("%s\n",stampa);
    printf("/// Tratta Viaggio: ");
    StampaPercorsoNominatoV(listaPercorso, vettoreCitta);
    printf("\n");
    strcpy(stampa, "/////////////////////////////////////////////////////////////////");
    printf("%s\n",stampa);
    printf("/// Tratta Albergo: ");
    StampaPercorsoNominato(listaVeloceCitta, vettoreHotel);
    printf("\n");
    printf("%s\n\n",stampa);
}
