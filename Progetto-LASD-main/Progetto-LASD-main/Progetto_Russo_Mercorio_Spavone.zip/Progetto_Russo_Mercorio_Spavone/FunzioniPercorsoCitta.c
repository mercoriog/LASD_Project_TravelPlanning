#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "StrutturaCitta.h"

struct nodo* CreaNodo(int val)
{
    struct nodo *new = (struct nodo*)malloc(sizeof(struct nodo));
    new->val = val;
    new->next = NULL;
    return new;
}


struct nodo* Push(struct nodo *L, int val)
{
    if(!L) return
        CreaNodo(val);
    else
    {
        L->next = Push(L->next, val);
        return L;
    }
}


struct nodo* Pop(struct nodo *L)
{
    if(L->next)
        L->next = Pop(L->next);
    else
    {
        free(L);
        return NULL;
    }
    return L;
}


struct nodo* Delete(struct nodo* P)
{
    while(P)
        P = Pop(P);
    return P;
}


struct nodo *Clone(struct nodo* P)
{
    struct nodo *new = NULL;
    while(P)
    {
        new = Push(new, P->val);
        P = P->next;
    }
    return new;
}


void StampaPercorso(struct nodo *L)
{
    if(L)
    {
        printf("%d -", L->val);
        if(L->next)
            StampaPercorso(L->next);
    }
    else
        printf("Percorso vuoto\n");
}


void StampaPercorsoNominato(struct nodo *L, char **vLuoghi)
{
    while(L->next!=NULL)
    {
        printf("%s ->", vLuoghi[L->val]);
        L = L->next;
    }
    printf("%s",vLuoghi[L->val]);
}


void Avanti(struct citta *G, int i, int arr, int *min, int parz, struct nodo *P, struct nodo **Pmin)
{
    struct tragitto *tmp;
    struct nodo *clone = NULL;

    if(i == arr)
    {
        if(parz < *min)
        {
            *min = parz;
            clone = Clone(P);
            *Pmin = clone;
        }
    }
    else
    {
        for(tmp = G->adiacente[i]; tmp; tmp = tmp->next)
            if(tmp->distanza + parz < *min && ricercaCitta(P, tmp->luogo)==0)
            {
                P = Push(P, tmp->luogo);
                clone = Clone(P);
                Avanti(G,tmp->luogo,arr, min, parz + tmp->distanza, clone, Pmin);
                clone = NULL;
                P = Pop(P);
            }
    }
    P = Delete(P);
}


struct nodo* TrovaPercorso(struct citta *G, int part, int arr, int *min)
{
    struct nodo *P = NULL, *Pmin = NULL, *clone = NULL;
    struct tragitto *tmp;

    P = Push(P, part);
    for(tmp = G->adiacente[part]; tmp; tmp = tmp->next)
    {
        P = Push(P, tmp->luogo);
        clone = Clone(P);
        Avanti(G, tmp->luogo,arr, min, tmp->distanza, clone, &Pmin);
        clone = NULL;
        P = Pop(P);
    }
    P = Pop(P);
    return Pmin;
}

