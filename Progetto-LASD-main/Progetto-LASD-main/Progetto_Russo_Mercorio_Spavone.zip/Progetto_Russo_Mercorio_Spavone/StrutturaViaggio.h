struct viaggio{
    int numCitta;
    struct tratta **adiacente;
};

struct tratta{
    int citta;
    int prezzoViaggio;
    int kmViaggio;
    struct tratta *next;
};

struct nodoViaggio{
    int val;
    struct nodoViaggio* next;
};


struct viaggio *creaGrafoViaggio(int n);
void aggiungiTrattaViaggio(struct viaggio *G, int partenza, int arrivo, int prezzo, int km);
struct viaggio *implementaGrafoViaggio(struct viaggio *G, FILE *fp);
int grafoVuoto(struct viaggio *G);
void stampaGrafoViaggio(struct viaggio *G);
char **leggiFileViaggioCitta(FILE *fp, int numCitta);
int contaNodi(FILE *fp);
void sceltaPartenzaeDestinazione(char **vettore, int numNodi);


struct nodoViaggio* CreaNodoV(int val);
struct nodoViaggio* PushV(struct nodoViaggio *L, int val);
struct nodoViaggio* PopV(struct nodoViaggio *L);
struct nodoViaggio* DeleteV(struct nodoViaggio *P);
struct nodoViaggio *CloneV(struct nodoViaggio *P);
void StampaPercorsoV(struct nodoViaggio *L);
void StampaPercorsoNominatoV(struct nodoViaggio *L, char **vLuoghi);
int ricercaN(struct nodoViaggio *L, int key);
void AvantiMinimoV(struct viaggio *G, int i, int arr, int *min, int parz, struct nodoViaggio *P, struct nodoViaggio **Pmin);
struct nodoViaggio* TrovaPercorsoMinimoV(struct viaggio *G, int part, int arr, int *min);
void AvantiEconomicoV(struct viaggio *G, int i, int arr, int *min, int parz, struct nodoViaggio *P, struct nodoViaggio **Pmin);
struct nodoViaggio* TrovaPercorsoEconomicoV(struct viaggio *G, int part, int arr, int *min);


void ScriviFileViaggio(char filename[], struct viaggio *G, char **vLuoghi);
void RimuoviTratta(struct viaggio *G, int part, int arr);
int EsisteTratta(struct viaggio *G, int part, int arr);
struct tratta *SvuotaTratte(struct tratta *L);
void EliminaBidirezione(struct viaggio *G, int cittaVittima);
struct viaggio *RimuoviNodo(struct viaggio *G, int cittaVittima);
char **UpdateVetLuoghi(char **vLuoghiOld, int cittaVittima, int nMax);
int collegamentoNodo(struct viaggio *G, int nodo);


void EliminaGrafo(struct viaggio *G);
void deallocaVettoreCitta(char **vettore,int numGrafo);
void deallocaListaViaggio(struct nodoViaggio *listaV);
