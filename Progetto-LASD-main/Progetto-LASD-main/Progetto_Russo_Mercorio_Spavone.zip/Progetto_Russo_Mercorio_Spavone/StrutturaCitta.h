struct citta{
    int nL;
    struct tragitto **adiacente;
};

struct tragitto{
    int luogo;
    int distanza;
    struct tragitto *next;
};

struct nodo{
    int val;
    struct nodo* next;
};


struct citta *CreaGrafo(int n);
void aggiungiArco(struct citta *G, int part, int arrivo, int dist);
int cittaVuota(struct citta *G);
void StampaCittaNominata(struct citta *G, char **vLuoghi);
void StampaCitta(struct citta *G);
char **leggiFileCitta(FILE *fp, int nLuoghi);
int contaLuoghi(FILE *fp);
void CaricaCitta(FILE *fp, struct citta *gCitta);
struct citta *CreaGrafoCitta(char *filename);
int ricercaCitta(struct nodo *L, int key);
void sceltaHotel(char **vettore, int numNodi);


struct nodo* CreaNodo(int val);
struct nodo* Push(struct nodo *L, int val);
struct nodo* Pop(struct nodo *L);
struct nodo* Delete(struct nodo* P);
struct nodo *Clone(struct nodo* P);
void StampaPercorso(struct nodo *L);
void StampaPercorsoNominato(struct nodo *L, char **vLuoghi);
void Avanti(struct citta *G, int i, int arr, int *min, int parz, struct nodo *P, struct nodo **Pmin);
struct nodo* TrovaPercorso(struct citta *G, int part, int arr, int *min);


void EliminaGrafoCitta(struct citta *G);
void deallocaListaCitta(struct nodo *listaC);
