#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <limits.h>
#include <curses.h>
#include "StrutturaViaggio.h"


struct nodoViaggio* CreaNodoV(int val)
{
    struct nodoViaggio *new = (struct nodoViaggio*)malloc(sizeof(struct nodoViaggio));
    new->val = val;
    new->next = NULL;
    return new;
}


struct nodoViaggio* PushV(struct nodoViaggio *L, int val)
{
    if(!L)
        return CreaNodoV(val);
    else
    {
        L->next = PushV(L->next, val);
        return L;
    }
}


struct nodoViaggio* PopV(struct nodoViaggio *L)
{
    if(L->next)
        L->next = PopV(L->next);
    else
    {
        free(L);
        return NULL;
    }
    return L;
}


struct nodoViaggio* DeleteV(struct nodoViaggio *P)
{
    while(P)
        P = PopV(P);
    return P;
}


struct nodoViaggio *CloneV(struct nodoViaggio *P)
{
    struct nodoViaggio *new = NULL;
    while(P)
    {
        new = PushV(new, P->val);
        P = P->next;
    }
    return new;
}


void StampaPercorsoV(struct nodoViaggio *L)
{
    if(L)
    {
        printf("%d -", L->val);
        if(L->next)
            StampaPercorsoV(L->next);
    }
    else
        printf("Percorso vuoto\n");
}


void StampaPercorsoNominatoV(struct nodoViaggio *L, char **vLuoghi)
{
    while(L->next!=NULL)
    {
        printf("%s ->", vLuoghi[L->val]);
        L = L->next;
    }
    printf("%s", vLuoghi[L->val]);
}


int ricercaN(struct nodoViaggio *L, int key)
{
    if(L)
    {
        if(L->val == key)
            return 1;
        else
            return ricercaN(L->next, key);
    }
    else
        return  0;
}


void AvantiMinimoV(struct viaggio *G, int i, int arr, int *min, int parz, struct nodoViaggio *P, struct nodoViaggio **Pmin)
{
    struct tratta *tmp;
    struct nodoViaggio *clone = NULL;

    if(i == arr)
    {
        if(parz < *min)
        {
            *min = parz;
            clone = CloneV(P);
            *Pmin = clone;
        }
    }
    else
    {
        for(tmp = G->adiacente[i]; tmp; tmp = tmp->next)
            if((tmp->kmViaggio + parz) < *min && ricercaN(P, tmp->citta)==0)
            {
                P = PushV(P, tmp->citta);
                clone = CloneV(P);
                AvantiMinimoV(G,tmp->citta,arr, min, parz + tmp->kmViaggio, clone, Pmin);
                clone = NULL;
                P = PopV(P);
            }
    }
    P = DeleteV(P);
}


struct nodoViaggio* TrovaPercorsoMinimoV(struct viaggio *G, int part, int arr, int *min)
{
    struct nodoViaggio *P = NULL, *Pmin = NULL, *clone = NULL;
    struct tratta *tmp;

    P = PushV(P, part);
    for(tmp = G->adiacente[part]; tmp; tmp = tmp->next)
    {
        P = PushV(P, tmp->citta);
        clone = CloneV(P);
        AvantiMinimoV(G, tmp->citta,arr, min, tmp->kmViaggio, clone, &Pmin);
        clone = NULL;
        P = PopV(P);
    }
    P = PopV(P);
    return Pmin;
}


void AvantiEconomicoV(struct viaggio *G, int i, int arr, int *min, int parz, struct nodoViaggio *P, struct nodoViaggio **Pmin)
{
    struct tratta *tmp;
    struct nodoViaggio *clone = NULL;

    if(i == arr)
    {
        if(parz < *min)
        {
            *min = parz;
            clone = CloneV(P);
            *Pmin = clone;
        }
    }
    else
    {
        for(tmp = G->adiacente[i]; tmp; tmp = tmp->next)
            if((tmp->prezzoViaggio + parz) < *min && ricercaN(P, tmp->citta)==0)
            {
                P = PushV(P, tmp->citta);
                clone = CloneV(P);
                AvantiEconomicoV(G,tmp->citta,arr, min, parz + tmp->prezzoViaggio, clone, Pmin);
                clone = NULL;
                P = PopV(P);
            }
    }
    P = DeleteV(P);
}


struct nodoViaggio* TrovaPercorsoEconomicoV(struct viaggio *G, int part, int arr, int *min)
{
    struct nodoViaggio *P = NULL, *Pmin = NULL, *clone = NULL;
    struct tratta *tmp;

    P = PushV(P, part);
    for(tmp = G->adiacente[part]; tmp; tmp = tmp->next)
    {
        P = PushV(P, tmp->citta);
        clone = CloneV(P);
        AvantiEconomicoV(G, tmp->citta,arr, min, tmp->prezzoViaggio, clone, &Pmin);
        clone = NULL;
        P = PopV(P);
    }
    P = PopV(P);
    return Pmin;
}
