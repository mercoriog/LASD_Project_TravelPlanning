struct richiesta{
    int src;
    int dest;
    struct richiesta *link;
};

struct richiesta *creaRichiesta (int src, int dest);
struct richiesta *inserimento(struct richiesta *lista, int src, int dest);
struct richiesta *leggiFileRichieste(struct richiesta *lista);
void scriviFileRichieste(struct richiesta *lista);
void stampaRichieste(struct richiesta *lista, char **vettore);


struct richiesta *rimuoviRichiesta(struct richiesta *lista, int src, int dest);
int ricerca(struct richiesta *lista, int src, int dest);
int counter(struct richiesta *lista);
struct richiesta *recuperaNodo(struct richiesta *lista, int index);
struct richiesta *rimuoviCitta(struct richiesta *lista, int citta);
struct richiesta *aggiornaRichieste(struct richiesta *lista, int eliminato);


void svuotaListaRichieste(struct richiesta *lista);
