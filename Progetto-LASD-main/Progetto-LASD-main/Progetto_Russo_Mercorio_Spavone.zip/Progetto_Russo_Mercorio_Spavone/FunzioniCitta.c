#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "StrutturaCitta.h"


struct citta *CreaGrafo(int n)
{
    struct citta *G;
    int i;
    G = (struct citta*)malloc(sizeof(struct citta));
    if (G==NULL)
        printf("ERRORE: impossibile allocare memoria per il grafo della citta\n");
    else
    {
        G->adiacente =(struct tragitto**)malloc(n*sizeof(struct tragitto*));
        if (G->adiacente==NULL)
        {
            printf("ERRORE: impossibile allocare memoria per la lista della citta\n");
            free(G);
            G=NULL;
        }
        else
        {
            G->nL=n;
            for (i=0; i<n; i++)
                G->adiacente[i]=NULL;
        }
    }
    return(G);
}


void aggiungiArco(struct citta *G, int part, int arrivo, int dist)
{
    struct tragitto *new, *tmp;
    new = (struct tragitto*)malloc(sizeof(struct tragitto));
    if (new==NULL)
        printf("ERRORE: impossibile allocare memoria \n");
    else
    {
        new->distanza = dist;
        new->luogo=arrivo;
        new->next=NULL;
        if (G->adiacente[part] == NULL)
            G->adiacente[part] = new;
        else
        {
            tmp=G->adiacente[part];
            while (tmp->next!=NULL)
                tmp=tmp->next;
            tmp->next=new;
        }
    }
}


int cittaVuota(struct citta *G)
{
    return (G==NULL);
}


void StampaCittaNominata(struct citta *G, char **vLuoghi)
{
    int i, contaTragitto=0;
    struct tragitto *tmp;
    if(!cittaVuota(G))
    {
        printf("\n La citta ha %d luoghi\n", G->nL);
        for (i=0; i<G->nL; i++)
        {
            printf("luoghi adiacenti a %s -> ", vLuoghi[i]);
            tmp = G->adiacente[i];
            while (tmp!=NULL)
            {
                printf("%s[%d] ", vLuoghi[tmp->luogo], tmp->distanza);
                contaTragitto=contaTragitto+1;
                tmp = tmp->next;
            }
            printf("\n");
        }
        printf("\n La citta ha %d tragitti\n", contaTragitto);
    }
}


void StampaCitta(struct citta *G)
{
    int i, contaTragitto=0;
    struct tragitto *tmp;
    if(!cittaVuota(G))
    {
        printf("\n La citta ha %d luoghi\n", G->nL);
        for (i=0; i<G->nL; i++)
        {
            printf("nodi adiacenti al nodo %d -> ", i);
            tmp =G->adiacente[i];
            while (tmp!=NULL)
            {
                printf("%d ", tmp->luogo);
                contaTragitto=contaTragitto+1;
                tmp=tmp->next;
            }
            printf("\n");
        }
        printf("\n La citta ha %d tragitti\n", contaTragitto);
    }
}


char **leggiFileCitta(FILE *fp, int nLuoghi)
{
    char nome[10];
    int contatore=0, i= 0;
    char **vet = NULL;
    vet=(char **)malloc(nLuoghi*sizeof(char*));
    
    for (i=0; i<nLuoghi; i++)
    {
        vet[i]=(char *)malloc(10*sizeof(char));
    }

    while(contatore<nLuoghi)
    {
        fscanf(fp, "%s ",nome);
        strcpy(vet[contatore], nome);
        contatore++;
    }

    return vet;
}


int contaLuoghi(FILE *fp)
{
    char nome[10];
    int contatore=0;
    do
    {
        fscanf(fp, "%s",nome);
        contatore++;
    }while((strcmp(nome, "@@"))!=0);

    contatore--;
    return contatore;
}


void CaricaCitta(FILE *fp, struct citta *gCitta)
{
    int part, arr, dist;
    while(fscanf(fp, "%d %d %d", &part, &arr, &dist) == 3)
    {
        aggiungiArco(gCitta, part, arr, dist);
    }
}


struct citta *CreaGrafoCitta(char *filename)
{
    struct citta *grafoCitta = NULL;
    int nLuoghi;
    FILE *fp = NULL;
    fp = fopen(filename, "r");
    nLuoghi = contaLuoghi(fp);
    grafoCitta = CreaGrafo(nLuoghi);
    CaricaCitta(fp, grafoCitta);
    fclose(fp);

    return grafoCitta;
}




int ricercaCitta(struct nodo *L, int key)
{
    if(L)
    {
        if(L->val == key)
            return 1;
        else
            return ricercaCitta(L->next, key);
    }
    else
        return  0;
}


void sceltaHotel(char **vettore, int numNodi)
{
    int i;
    for (i=2; i<numNodi; i++)
    {
        printf("%d -%s\n",i-2,vettore[i]);
    }
}


void EliminaGrafoCitta(struct citta *G)
{
    int i;
    struct tragitto *tmp=NULL, *tmpnext = NULL;
    if(G!= NULL)
    {
        if(G->nL > 0)
        {
            for(i=0; i<G->nL; i++)
            {
                tmp = G->adiacente[i];
                while(tmp!=NULL)
                {
                    tmpnext = tmp->next;
                    free(tmp);
                    tmp = tmpnext;
                }
            }
            free(G->adiacente);
        }
        free(G);
        G = NULL;
    }
}


void deallocaListaCitta(struct nodo *listaC)
{
  struct nodo *tmp;
  tmp=listaC;
  while(listaC!=NULL)
  {
    listaC=listaC->next;
    free(tmp);
    tmp=listaC;
  }
}
