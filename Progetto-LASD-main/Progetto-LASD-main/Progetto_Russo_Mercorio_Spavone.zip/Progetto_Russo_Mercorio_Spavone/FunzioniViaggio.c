#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <limits.h>
#include <curses.h>
#include "StrutturaViaggio.h"


struct viaggio *creaGrafoViaggio(int n)
{
    struct viaggio *G;
    int i;
    G = (struct viaggio*)malloc(sizeof(struct viaggio));
    if (G==NULL)
        printf("ERRORE: impossibile allocare memoria per il grafo\n");
    else
    {
        G->adiacente =(struct tratta**)malloc(n*sizeof(struct tratta*));
        if (G->adiacente==NULL)
        {
            printf("ERRORE: impossibile allocare memoria per la lista del grafo\n");
            free(G);
            G=NULL;
        }
        else
        {
            G->numCitta=n;
            for (i=0; i<n; i++)
                G->adiacente[i]=NULL;
        }
    }
    return(G);
}


void aggiungiTrattaViaggio(struct viaggio *G, int partenza, int arrivo, int prezzo, int km)
{
    struct tratta *nuovoArco, *tmp;
    nuovoArco = (struct tratta*)malloc(sizeof(struct tratta));
    if (nuovoArco==NULL)
        printf("ERRORE: impossibile allocare memoria \n");
    else
    {
        nuovoArco->citta=arrivo;
        nuovoArco->kmViaggio=km;
        nuovoArco->prezzoViaggio=prezzo;
        nuovoArco->next=NULL;
        if (G->adiacente[partenza] == NULL)
            G->adiacente[partenza] = nuovoArco;
        else
        {
            tmp=G->adiacente[partenza];
            while (tmp->next!=NULL)
                tmp=tmp->next;
            tmp->next=nuovoArco;
        }
    }
}


struct viaggio *implementaGrafoViaggio(struct viaggio *G, FILE *fp)
{
    int numeroNodi;
    numeroNodi=contaNodi(fp);
    G=creaGrafoViaggio(numeroNodi);
    int partenza, arrivo, prezzo, km;
    while ((fscanf(fp, "%d %d %d %d",&partenza,&arrivo,&prezzo,&km))==4)
    {
        aggiungiTrattaViaggio(G, partenza, arrivo, km, prezzo);
    }
    return G;
}


int grafoVuoto(struct viaggio *G)
{
    return (G==NULL);
}


void stampaGrafoViaggio(struct viaggio *G)
{
    int i;
    struct tratta *elemento;
    if(!grafoVuoto(G))
    {
        printf("\nIl grafo ha %d vertici\n", G->numCitta);
        for (i=0; i<G->numCitta; i++)
        {
            printf("nodi adiacenti al nodo %d -> ", i);
            elemento=G->adiacente[i];
            while (elemento!=NULL)
            {
                printf("%d ", elemento->citta);
                elemento=elemento->next;
            }
            printf("\n");
        }
    }
}


char **leggiFileViaggioCitta(FILE *fp, int numCitta)
{
    char nome[10];
    int contatore=0;
    char **vet;
    vet=(char **)malloc(numCitta*sizeof(char*));
    for (int i=0; i<numCitta; i++)
    {
        vet[i]=(char *)malloc(10*sizeof(char));
    }
    while(contatore<numCitta)
    {
        fscanf(fp, "%s",nome);
        strcpy(vet[contatore], nome);
        contatore++;
    }
    return vet;
}


int contaNodi(FILE *fp)
{
    char nome[10];
    int contatore=0;
    do
    {
        fscanf(fp, "%s",nome);
        contatore++;
    }while((strcmp(nome, "@@"))!=0);
    contatore--;
    return contatore;
}


void sceltaPartenzaeDestinazione(char **vettore, int numNodi)
{
    int i;
    for (i=0; i<numNodi; i++)
    {
        printf("%d -%s\n",i,vettore[i]);
    }
}


void ScriviFileViaggio(char filename[], struct viaggio *G, char **vLuoghi)
{
    int i, contaTragitto=0;
    struct tratta *tmp;
    FILE *fp = NULL;
    fp = fopen(filename, "w");

    if(!fp)
    {
        printf("Errore nell apertura del file citta\n");
        return;
    }

    for (i=0; i<G->numCitta; i++)
    {
        fprintf(fp, "%s ", vLuoghi[i]);
    }
    fprintf(fp, "@@\n");

    if(!grafoVuoto(G))
    {
        for (i=0; i<G->numCitta; i++)
        {
            tmp =G->adiacente[i];
            while (tmp!=NULL)
            {
                fprintf(fp,"%d %d %d %d\n", i, tmp->citta, tmp->kmViaggio, tmp->prezzoViaggio);
                contaTragitto=contaTragitto+1;
                tmp=tmp->next;
            }
        }
    }
    fclose(fp);
}


void RimuoviTratta(struct viaggio *G, int part, int arr)
{
    struct tratta *curr = NULL, *prev = NULL;
    curr = G->adiacente[part];

    if(curr==NULL)
        return;
    else if(curr->citta == arr)
    {
        G->adiacente[part] = curr->next;
        free(curr);
    }
    else
    {
        while(curr->citta != arr && curr->next!=NULL)
        {
            prev = curr;
            curr = curr->next;
        }
        if(curr->citta == arr){
            prev->next = curr->next;
            free(curr);
        }
    }
}


int EsisteTratta(struct viaggio *G, int part, int arr)
{
    struct tratta *curr = NULL;

    curr = G->adiacente[part];
    while(curr)
    {
        if(curr->citta == arr)
            return 1;
        else
            curr = curr->next;
    }
    return 0;
}


int collegamentoNodo(struct viaggio *G, int nodo)
{
    struct tratta *curr = NULL;

    curr = G->adiacente[nodo];
    while(curr)
    {
            return 1;
    }
    return 0;
}


void EliminaGrafo(struct viaggio *G)
{
    int i;
    struct tratta *tmp=NULL, *tmpnext = NULL;
    if(G!= NULL)
    {
        if(G->numCitta > 0)
        {
            for(i=0; i<G->numCitta; i++)
            {
                tmp = G->adiacente[i];
                while(tmp!=NULL)
                {
                    tmpnext = tmp->next;
                    free(tmp);
                    tmp = tmpnext;
                }
            }
            free(G->adiacente);
        }
        free(G);
        G = NULL;
    }
}


struct tratta *SvuotaTratte(struct tratta *L)
{
    if(L)
    {
        if(L->next) L->next = SvuotaTratte(L->next);
        free(L);
    }
    return NULL;
}


void EliminaBidirezione(struct viaggio *G, int cittaVittima)
{
    int i;
    for(i = 0; i<G->numCitta; i++)
    {
        if(EsisteTratta(G, i, cittaVittima) == 1)
            RimuoviTratta(G, i, cittaVittima);
    }
}


struct viaggio *RimuoviNodo(struct viaggio *G, int cittaVittima)
{
    struct tratta *tmp= NULL;
    struct viaggio *nuovoGrafo=NULL;
    int i, j;

    EliminaBidirezione(G, cittaVittima);
    G->adiacente[cittaVittima] = SvuotaTratte(G->adiacente[cittaVittima]);

    nuovoGrafo = creaGrafoViaggio(G->numCitta - 1);
    i = 0;
    j = 0;
    while(i < G->numCitta)
    {
        if (i == cittaVittima)
            i++;
        else
        {
            for(tmp = G->adiacente[i]; tmp; tmp = tmp->next)
            {
                if(tmp->citta > cittaVittima)
                    aggiungiTrattaViaggio(nuovoGrafo, j, tmp->citta-1, tmp->prezzoViaggio, tmp->kmViaggio);
                else
                    aggiungiTrattaViaggio(nuovoGrafo, j, tmp->citta, tmp->prezzoViaggio, tmp->kmViaggio);
            }
            i++;
            j++;
        }
    }
    EliminaGrafo(G);
    return nuovoGrafo;
}


char **UpdateVetLuoghi(char **vLuoghiOld, int cittaVittima, int nMax)
{
    int i = 0, j = 0;
    int nLuoghi = nMax -1;
    char **vetLuoghi=NULL;

    vetLuoghi=(char **)malloc(nLuoghi*sizeof(char*));

    for (i=0; i<nLuoghi; i++)
    {
        vetLuoghi[i]=(char *)malloc(10*sizeof(char));
    }

    i = 0;
    while(i<nMax)
    {
        if(i == cittaVittima)
            i++;
        else
        {
            strcpy(vetLuoghi[j], vLuoghiOld[i]);
            i++;
            j++;
        }
    }
    return vetLuoghi;
}


void deallocaVettoreCitta(char **vettore,int numGrafo)
{
  int i;
  for(i=0;i<numGrafo;i++)
    free(vettore[i]);
  free(vettore);
}


void deallocaListaViaggio(struct nodoViaggio *listaV)
{
  struct nodoViaggio *tmp;
  tmp=listaV;
  while(listaV!=NULL)
  {
    listaV=listaV->next;
    free(tmp);
    tmp=listaV;
  }
}
